package MySql;

public class AppConstants {

    public static String userType = "";
    public static String userID = "";
}
