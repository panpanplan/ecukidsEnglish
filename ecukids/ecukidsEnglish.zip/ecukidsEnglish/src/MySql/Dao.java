package MySql;

/**
 * 枚举所有表格
 */
public enum Dao {
    classDao,
    messageDao,
    qiandaoDao,
    resultDao,
    selectclassDao,
    userDao;
}
